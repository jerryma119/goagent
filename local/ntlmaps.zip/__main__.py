#! /usr/bin/python

# This file is part of 'NTLM Authorization Proxy Server'
# Copyright 2001 Dmitry A. Rozmanov <dima@xenon.spb.ru>
#
# NTLM APS is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# NTLM APS is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with the sofware; see the file COPYING. If not, write to the
# Free Software Foundation, Inc.,
# 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA.
#

import sys, os

sys.dont_write_bytecode = True
sys.path.extend([__file__, '.'])


import server, config_affairs

if __name__ == '__main__':
    conf = {
               "DEBUG":{
                  "DEBUG":"0",
                  "AUTH_DEBUG":"0",
                  "SCR_DEBUG":"0",
                  "BIN_DEBUG":"0"
               },
               "CLIENT_HEADER":{
                  "Accept":"image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, application/vnd.ms-excel, application/msword, application/vnd.ms-powerpoint, */*",
                  "User-Agent":"Mozilla/4.0 (compatible; MSIE 5.5; Windows 98)"
               },
               "NTLM_AUTH":{
                  "NT_PART":"0",
                  "NTLM_FLAGS":"06820000",
                  "NTLM_TO_BASIC":"0",
                  "LM_PART":"1",
                  "USER":"username_to_use",
                  "NT_DOMAIN":"your_domain",
                  "PASSWORD":"your_nt_password",
                  "NT_HOSTNAME":""
               },
               "GENERAL":{
                  "ALLOW_EXTERNAL_CLIENTS":"0",
                  "LISTEN_PORT":"5865",
                  "URL_LOG":"0",
                  "PARENT_PROXY":"your_parentproxy",
                  "PARENT_PROXY_TIMEOUT":"15",
                  "MAX_CONNECTION_BACKLOG":"5",
                  "PARENT_PROXY_PORT":"8080",
                  "FRIENDLY_IPS":"",
                  "VERSION":"0.9.9.0.1"
               }
            }

    for env in os.environ:
        if env.startswith('NTLMAPS-'):
            _, section, key = env.split('-')
            conf.setdefault(section, {})[key] = os.environ[env]

    print 'NTLM authorization Proxy Server v%s' % conf['GENERAL']['VERSION']
    print 'Copyright (C) 2001-2004 by Dmitry Rozmanov and others.'

    config = config_affairs.arrange(conf)
    serv = server.AuthProxyServer(config)
    serv.run()
