
import sys

def main(argv):
    sys.path.extend([__file__, '.'])
    import google.appengine.tools.appcfg
    google.appengine.tools.appcfg.main(argv)

if __name__ == '__main__':
    main(sys.argv)